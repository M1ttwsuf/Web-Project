package User;

public class UserDTO {
	private String uname;
	private String upwd;
	private String uemail;
	private String ustudentnumber;
	
	private String uEmailHash;
	private boolean uEmailChecked;

	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpwd() {
		return upwd;
	}
	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getUstudentnumber() {
		return ustudentnumber;
	}
	public void setUstudentnumber(String ustudentnumber) {
		this.ustudentnumber = ustudentnumber;
	}
	public String getuEmailHash() {
		return uEmailHash;
	}
	public void setuEmailHash(String uEmailHash) {
		this.uEmailHash = uEmailHash;
	}
	public boolean isuEmailChecked() {
		return uEmailChecked;
	}
	public void setuEmailChecked(boolean uEmailChecked) {
		this.uEmailChecked = uEmailChecked;
	}
	public UserDTO() {
		
	}
	public UserDTO(String uname, String upwd, String uemail, String ustudentnumber, 
			String uEmailHash, boolean uEmailChecked) {
		this.uname = uname;
		this.upwd = upwd;
		this.uemail = uemail;
		this.ustudentnumber = ustudentnumber;
		this.uEmailHash = uEmailHash;
		this.uEmailChecked = uEmailChecked;
	}
}

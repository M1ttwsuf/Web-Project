package User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
	private Connection conn;
//	private PreparedStatement pstmt;
//	private ResultSet rs;

	public UserDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/youtube";
			String dbID = "root";
			String dbPassword = "root";
			Class.forName("com.cj.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

//	public int login(String ustudentnumber, String upwd) {
//		String SQL = "SELECT upwd FROM USER WHERE ustudentnumber = ?";
//		try {
//			pstmt = conn.prepareStatement(SQL);
//			pstmt.setString(1, ustudentnumber);
//			rs = pstmt.executeQuery();
//			if (rs.next()) {
//				if (rs.getString(1).equals(upwd))
//					return 1; // �α��� ����
//				else
//					return 0; // ��й�ȣ ����ġ
//			}
//			return -1; // ID�� ����
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return -2; // DB ����
//
//	}
}
